/*!

* sense-funnel-chart - Funnel Chart for Qlik Sense.
*
* @version v1.3.13
* @link https://github.com/stefanwalther/sense-funnel-chart
* @author Stefan Walther
* @license MIT
*/


define([],function(){"use strict";var dimensions={uses:"dimensions",min:1,max:1},measures={uses:"measures",min:1,max:1},sorting={uses:"sorting"},chartInverted={ref:"props.chartInverted",type:"boolean",component:"switch",label:"Inverted",options:[{value:!0,label:"On"},{value:!1,label:"Off"}],defaultValue:!1},chartCurved={ref:"props.chartCurved",type:"boolean",component:"switch",label:"Curved layout",options:[{value:!0,label:"On"},{value:!1,label:"Off"}],defaultValue:!1},chartBottomPinch={ref:"props.chartBottomPinch",type:"number",component:"slider",label:"Bottom pinch",min:0,max:10,step:1,defaultValue:0},appearancePanel={uses:"settings",items:{settings:{type:"items",label:"Presentation",items:{chartInverted:chartInverted,chartCurved:chartCurved,chartBottomPinch:chartBottomPinch}}}};return{type:"items",component:"accordion",items:{dimensions:dimensions,measures:measures,sorting:sorting,appearance:appearancePanel}}});